module.exports = {
  PINTEREST_API_BASE: 'https://api.amitdas.site/Pinterest/api/',
  WHATSAPP_INSTANCE_ID: 'YOUR_INSTANCE_ID',
  WHATSAPP_ACCESS_TOKEN: 'YOUR_ACCESS_TOKEN'
};
